
package SocialMedia_Report;

/**
 * Interface of Column
 * @author Sebastian
 */
public interface Column extends CompositeParagraph {
}
