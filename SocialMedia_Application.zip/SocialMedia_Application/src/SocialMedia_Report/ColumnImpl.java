package SocialMedia_Report;

import java.rmi.RemoteException;

// <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
// #[regen=yes,id=DCE.E2835B7A-5082-CB02-F27E-C9D66453A1DE]
// </editor-fold> 

/**
 * Implementation of Column
 * @author Sebastian
 */
public class ColumnImpl extends CompositeParagraphImpl implements Column {

    /**
     * Constructor of the class
     * @throws RemoteException
     */
    public ColumnImpl() throws RemoteException{
        super();
    }
}

