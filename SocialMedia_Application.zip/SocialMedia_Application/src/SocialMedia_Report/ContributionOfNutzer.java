
package SocialMedia_Report;

/**
 * Interface class for the ContributionOfNutzer report
 * @author Sebastian
 */
public interface ContributionOfNutzer extends Report{
    
}
