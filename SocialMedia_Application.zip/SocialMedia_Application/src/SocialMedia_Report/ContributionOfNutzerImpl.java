package SocialMedia_Report;

import java.rmi.RemoteException;


// <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
// #[regen=yes,id=DCE.9015A86E-4FA0-CF21-CDF2-EBF794A398CC]
// </editor-fold> 
/**
 * Implementation class for the ContributionOfNutzer report
 * @author Max
 */
public class ContributionOfNutzerImpl extends ReportImpl implements ContributionOfNutzer{

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.E349587E-675F-E79D-0277-31072E9BDDD6]
    // </editor-fold>
    /* Constructor of the ContributionOfNutzerImpl class
     * @throws java.rmi.RemoteException
     */
    public ContributionOfNutzerImpl () 
            throws RemoteException{
        super();
    }

}

