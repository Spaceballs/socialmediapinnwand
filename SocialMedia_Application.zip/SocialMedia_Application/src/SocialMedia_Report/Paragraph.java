
package SocialMedia_Report;

/**
 * Interface of the abstract class for Paragraph
 * @author Sebastian
 */
public abstract interface Paragraph extends java.rmi.Remote{
    
}
