
package SocialMedia_Report;

/**
 * Interface class for the PopularityOfBeitrag report
 * @author Sebastian
 */
public interface PopularityOfBeitrag extends Report{

    
}
