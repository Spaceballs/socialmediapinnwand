package SocialMedia_Report;

import java.rmi.RemoteException;

/**
 * Implementation class for the PopularityOfBeitrag report
 * @author Max
 */
public class PopularityOfBeitragImpl extends ReportImpl implements PopularityOfBeitrag{

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.EDCE594B-47D4-552E-4534-E0E3A32843EF]
    // </editor-fold>
    /* Constructor of the PopularityOfBeitragImpl class
     * @throws java.rmi.RemoteException
     */
    public PopularityOfBeitragImpl () 
            throws RemoteException{
        super();
    }
}

