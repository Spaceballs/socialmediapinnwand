/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package SocialMedia_Data;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 *
 * @author Sebastian Fink
 */
@RunWith(Suite.class)
@Suite.SuiteClasses({SocialMedia_Data.KommentarImplTest.class, SocialMedia_Data.UserCreatedContentTest.class, SocialMedia_Data.PinnwandImplTest.class, SocialMedia_Data.AbonnementTest.class, SocialMedia_Data.KommentarTest.class, SocialMedia_Data.LikeImplTest.class, SocialMedia_Data.UserCreatedContentImplTest.class, SocialMedia_Data.DataReferenceImplTest.class, SocialMedia_Data.AbonnementImplTest.class, SocialMedia_Data.BeitragTest.class, SocialMedia_Data.BeitragImplTest.class, SocialMedia_Data.DataReferenceTest.class, SocialMedia_Data.NutzerTest.class, SocialMedia_Data.LikeTest.class, SocialMedia_Data.NutzerImplTest.class, SocialMedia_Data.PinnwandTest.class})
public class SocialMedia_DataSuite {

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }
    
}
