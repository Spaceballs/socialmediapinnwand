/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package SocialMedia_Gui;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 *
 * @author Sebastian Fink
 */
@RunWith(Suite.class)
@Suite.SuiteClasses({SocialMedia_Gui.PinnwandPanelTest.class, SocialMedia_Gui.AbonnementPanelTest.class, SocialMedia_Gui.HauptfensterTest.class, SocialMedia_Gui.DialogSuchenTest.class, SocialMedia_Gui.Ressources.RessourcesSuite.class, SocialMedia_Gui.NutzerInfoTest.class, SocialMedia_Gui.DialogRegistrierenTest.class, SocialMedia_Gui.DialogBeitragTest.class, SocialMedia_Gui.NewsfeedTest.class, SocialMedia_Gui.DialogAnmeldenTest.class, SocialMedia_Gui.KommentarPanelTest.class, SocialMedia_Gui.HauptfensterReportTest.class, SocialMedia_Gui.DialogServerDataTest.class, SocialMedia_Gui.NewsfeedPanelTest.class, SocialMedia_Gui.DialogNutzerTest.class, SocialMedia_Gui.AbonnementInfoTest.class, SocialMedia_Gui.BeitragPanelTest.class})
public class SocialMedia_GuiSuite {

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }
    
}
